The host keeps its database and keys here (a Docker volume).
